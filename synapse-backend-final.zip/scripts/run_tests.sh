"""Script para execução de testes e validação de cobertura.

Este script executa todos os testes unitários e de integração,
gera relatório de cobertura e valida a conformidade com boas práticas.
"""

import os
import subprocess
import sys

# Cores para output
GREEN = "\033[92m"
YELLOW = "\033[93m"
RED = "\033[91m"
RESET = "\033[0m"
BOLD = "\033[1m"

def print_header(message):
    """Imprime cabeçalho formatado."""
    print(f"\n{BOLD}{YELLOW}{'='*80}{RESET}")
    print(f"{BOLD}{YELLOW}= {message}{RESET}")
    print(f"{BOLD}{YELLOW}{'='*80}{RESET}\n")

def run_command(command, exit_on_error=True):
    """Executa comando e retorna resultado."""
    print(f"{BOLD}Executando:{RESET} {' '.join(command)}")
    result = subprocess.run(command, capture_output=True, text=True)
    
    if result.returncode == 0:
        print(f"{GREEN}Comando executado com sucesso!{RESET}")
        if result.stdout:
            print(result.stdout)
    else:
        print(f"{RED}Erro ao executar comando:{RESET}")
        print(result.stderr)
        if exit_on_error:
            sys.exit(1)
    
    return result.returncode == 0

def main():
    """Função principal."""
    print_header("Iniciando validação do backend SynapScale")
    
    # Verificar formatação e estilo de código
    print_header("Verificando formatação e estilo de código")
    run_command(["flake8", "src", "tests"])
    
    # Verificar tipos
    print_header("Verificando tipagem")
    run_command(["mypy", "src"])
    
    # Executar testes unitários
    print_header("Executando testes unitários")
    run_command(["pytest", "tests/unit", "-v"])
    
    # Executar testes de integração
    print_header("Executando testes de integração")
    run_command(["pytest", "tests/integration", "-v"])
    
    # Gerar relatório de cobertura
    print_header("Gerando relatório de cobertura")
    run_command(["pytest", "--cov=src", "--cov-report=term", "--cov-report=html:coverage_report"])
    
    # Verificar segurança
    print_header("Verificando vulnerabilidades de segurança")
    run_command(["bandit", "-r", "src"])
    
    print_header("Validação concluída com sucesso!")
    print(f"{GREEN}{BOLD}O backend SynapScale está pronto para empacotamento e entrega.{RESET}")

if __name__ == "__main__":
    main()
