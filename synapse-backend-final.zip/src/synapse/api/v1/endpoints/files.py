"""Endpoints para gerenciamento de arquivos.

Este módulo implementa os endpoints da API para upload, download,
listagem e gerenciamento de arquivos.
"""

import logging
from typing import List, Optional
from uuid import UUID

from fastapi import APIRouter, Depends, File, Form, HTTPException, Query, UploadFile, status
from sqlalchemy.ext.asyncio import AsyncSession

from .....constants import FILE_CATEGORIES
from .....core.auth import get_current_user
from .....db import get_db
from .....exceptions import file_validation_exception
from .....middlewares import rate_limit
from .....schemas.file import (
    FileDownloadResponse,
    FileListResponse,
    FileResponse,
    FileUpdate,
    FileUploadResponse,
)
from .....services import FileService

# Logger
logger = logging.getLogger(__name__)

# Router
router = APIRouter(prefix="/files", tags=["files"])

# Serviço
file_service = FileService()


@router.post(
    "/upload",
    response_model=FileUploadResponse,
    status_code=status.HTTP_201_CREATED,
    summary="Fazer upload de arquivo",
    description="Faz upload de um arquivo para o sistema, categorizando e armazenando-o de forma segura.",
)
async def upload_file(
    file: UploadFile = File(...),
    category: str = Form(...),
    tags: Optional[str] = Form(None),
    description: Optional[str] = Form(None),
    is_public: bool = Form(False),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
    _: dict = Depends(rate_limit()),
):
    """Faz upload de um arquivo para o sistema.
    
    Este endpoint permite que usuários autenticados façam upload de arquivos,
    categorizem e adicionem tags para facilitar a organização.
    
    Args:
        file: O arquivo a ser enviado
        category: Categoria do arquivo (image, video, audio, document, archive)
        tags: Tags separadas por vírgula (opcional)
        description: Descrição do arquivo (opcional)
        is_public: Se o arquivo deve ser público (opcional, padrão: False)
        current_user: Usuário autenticado (injetado via dependência)
        db: Sessão do banco de dados (injetada via dependência)
        _: Rate limiting (injetado via dependência)
        
    Returns:
        FileUploadResponse: Resposta contendo ID do arquivo e mensagem de sucesso
        
    Raises:
        HTTPException 400: Se o arquivo não passar nas validações de segurança
        HTTPException 401: Se o usuário não estiver autenticado
        HTTPException 429: Se o limite de taxa for excedido
        HTTPException 500: Se ocorrer um erro interno no servidor
    """
    try:
        # Validar categoria
        if category not in FILE_CATEGORIES:
            raise file_validation_exception(
                f"Categoria inválida. Deve ser uma das: {', '.join(FILE_CATEGORIES)}"
            )
        
        # Processar tags
        tag_list = None
        if tags:
            tag_list = [tag.strip() for tag in tags.split(",") if tag.strip()]
        
        # Criar objeto de dados
        file_data = {
            "filename": file.filename,
            "category": category,
            "tags": tag_list,
            "description": description,
            "is_public": is_public,
        }
        
        # Fazer upload
        db_file = await file_service.upload_file(
            db=db,
            file=file,
            user_id=current_user["id"],
            file_data=FileUpdate(**file_data),
        )
        
        return FileUploadResponse(
            file_id=db_file.id,
            message="Arquivo enviado com sucesso",
        )
    except Exception as e:
        logger.error(f"Erro no upload de arquivo: {str(e)}")
        if isinstance(e, HTTPException):
            raise
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro ao processar upload: {str(e)}",
        )


@router.get(
    "/",
    response_model=FileListResponse,
    summary="Listar arquivos",
    description="Lista os arquivos do usuário com suporte a paginação e filtragem por categoria.",
)
async def list_files(
    page: int = Query(1, ge=1, description="Número da página"),
    size: int = Query(10, ge=1, le=100, description="Tamanho da página"),
    category: Optional[str] = Query(None, description="Filtrar por categoria"),
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Lista os arquivos do usuário.
    
    Este endpoint retorna uma lista paginada dos arquivos do usuário,
    com opção de filtragem por categoria.
    
    Args:
        page: Número da página (começa em 1)
        size: Tamanho da página (máximo 100)
        category: Filtrar por categoria (opcional)
        current_user: Usuário autenticado (injetado via dependência)
        db: Sessão do banco de dados (injetada via dependência)
        
    Returns:
        FileListResponse: Lista paginada de arquivos
        
    Raises:
        HTTPException 401: Se o usuário não estiver autenticado
        HTTPException 500: Se ocorrer um erro interno no servidor
    """
    try:
        # Validar categoria se fornecida
        if category and category not in FILE_CATEGORIES:
            raise HTTPException(
                status_code=status.HTTP_400_BAD_REQUEST,
                detail=f"Categoria inválida. Deve ser uma das: {', '.join(FILE_CATEGORIES)}",
            )
        
        # Calcular skip para paginação
        skip = (page - 1) * size
        
        # Buscar arquivos
        files, total = await file_service.list_files(
            db=db,
            user_id=current_user["id"],
            skip=skip,
            limit=size,
            category=category,
        )
        
        # Calcular total de páginas
        pages = (total + size - 1) // size if total > 0 else 1
        
        # Converter para resposta
        items = [FileResponse.from_orm(file) for file in files]
        
        return FileListResponse(
            items=items,
            total=total,
            page=page,
            size=size,
            pages=pages,
        )
    except Exception as e:
        logger.error(f"Erro ao listar arquivos: {str(e)}")
        if isinstance(e, HTTPException):
            raise
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro ao listar arquivos: {str(e)}",
        )


@router.get(
    "/{file_id}",
    response_model=FileResponse,
    summary="Obter informações do arquivo",
    description="Retorna informações detalhadas sobre um arquivo específico.",
)
async def get_file(
    file_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Obtém informações detalhadas de um arquivo.
    
    Este endpoint retorna informações detalhadas sobre um arquivo específico,
    verificando se o usuário tem permissão para acessá-lo.
    
    Args:
        file_id: ID do arquivo
        current_user: Usuário autenticado (injetado via dependência)
        db: Sessão do banco de dados (injetada via dependência)
        
    Returns:
        FileResponse: Informações detalhadas do arquivo
        
    Raises:
        HTTPException 401: Se o usuário não estiver autenticado
        HTTPException 404: Se o arquivo não for encontrado ou o usuário não tiver permissão
        HTTPException 500: Se ocorrer um erro interno no servidor
    """
    try:
        # Buscar arquivo
        file = await file_service.get_file(
            db=db,
            file_id=file_id,
            user_id=current_user["id"],
        )
        
        return FileResponse.from_orm(file)
    except Exception as e:
        logger.error(f"Erro ao obter arquivo {file_id}: {str(e)}")
        if isinstance(e, HTTPException):
            raise
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro ao obter arquivo: {str(e)}",
        )


@router.get(
    "/{file_id}/download",
    response_model=FileDownloadResponse,
    summary="Gerar URL de download",
    description="Gera uma URL temporária para download do arquivo.",
)
async def download_file(
    file_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Gera URL para download de um arquivo.
    
    Este endpoint gera uma URL temporária para download do arquivo,
    verificando se o usuário tem permissão para acessá-lo.
    
    Args:
        file_id: ID do arquivo
        current_user: Usuário autenticado (injetado via dependência)
        db: Sessão do banco de dados (injetada via dependência)
        
    Returns:
        FileDownloadResponse: URL de download e data de expiração
        
    Raises:
        HTTPException 401: Se o usuário não estiver autenticado
        HTTPException 404: Se o arquivo não for encontrado ou o usuário não tiver permissão
        HTTPException 500: Se ocorrer um erro interno no servidor
    """
    try:
        # Gerar URL de download
        download_info = await file_service.generate_download_url(
            db=db,
            file_id=file_id,
            user_id=current_user["id"],
        )
        
        return FileDownloadResponse(
            download_url=download_info["download_url"],
            expires_at=download_info["expires_at"],
        )
    except Exception as e:
        logger.error(f"Erro ao gerar URL de download para arquivo {file_id}: {str(e)}")
        if isinstance(e, HTTPException):
            raise
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro ao gerar URL de download: {str(e)}",
        )


@router.patch(
    "/{file_id}",
    response_model=FileResponse,
    summary="Atualizar informações do arquivo",
    description="Atualiza informações de um arquivo específico.",
)
async def update_file(
    file_id: UUID,
    file_update: FileUpdate,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Atualiza informações de um arquivo.
    
    Este endpoint permite atualizar tags, descrição e visibilidade de um arquivo,
    verificando se o usuário é o proprietário.
    
    Args:
        file_id: ID do arquivo
        file_update: Dados atualizados do arquivo
        current_user: Usuário autenticado (injetado via dependência)
        db: Sessão do banco de dados (injetada via dependência)
        
    Returns:
        FileResponse: Informações atualizadas do arquivo
        
    Raises:
        HTTPException 401: Se o usuário não estiver autenticado
        HTTPException 404: Se o arquivo não for encontrado ou o usuário não for o proprietário
        HTTPException 500: Se ocorrer um erro interno no servidor
    """
    try:
        # Atualizar arquivo
        updated_file = await file_service.update_file(
            db=db,
            file_id=file_id,
            user_id=current_user["id"],
            file_data=file_update,
        )
        
        return FileResponse.from_orm(updated_file)
    except Exception as e:
        logger.error(f"Erro ao atualizar arquivo {file_id}: {str(e)}")
        if isinstance(e, HTTPException):
            raise
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro ao atualizar arquivo: {str(e)}",
        )


@router.delete(
    "/{file_id}",
    status_code=status.HTTP_204_NO_CONTENT,
    summary="Remover arquivo",
    description="Remove um arquivo do sistema.",
)
async def delete_file(
    file_id: UUID,
    current_user: dict = Depends(get_current_user),
    db: AsyncSession = Depends(get_db),
):
    """Remove um arquivo do sistema.
    
    Este endpoint remove um arquivo do sistema, tanto do armazenamento
    quanto do banco de dados, verificando se o usuário é o proprietário.
    
    Args:
        file_id: ID do arquivo
        current_user: Usuário autenticado (injetado via dependência)
        db: Sessão do banco de dados (injetada via dependência)
        
    Returns:
        204 No Content
        
    Raises:
        HTTPException 401: Se o usuário não estiver autenticado
        HTTPException 404: Se o arquivo não for encontrado ou o usuário não for o proprietário
        HTTPException 500: Se ocorrer um erro interno no servidor
    """
    try:
        # Remover arquivo
        await file_service.delete_file(
            db=db,
            file_id=file_id,
            user_id=current_user["id"],
        )
    except Exception as e:
        logger.error(f"Erro ao remover arquivo {file_id}: {str(e)}")
        if isinstance(e, HTTPException):
            raise
        raise HTTPException(
            status_code=status.HTTP_500_INTERNAL_SERVER_ERROR,
            detail=f"Erro ao remover arquivo: {str(e)}",
        )
