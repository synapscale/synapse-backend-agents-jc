"""Modelo de arquivo para o banco de dados.

Este módulo contém o modelo de dados para arquivos armazenados no sistema.
"""

import datetime
import uuid
from typing import List, Optional

from sqlalchemy import Column, DateTime, ForeignKey, Index, String, Text
from sqlalchemy.dialects.postgresql import ARRAY, UUID
from sqlalchemy.orm import relationship

from ...db.base import Base


class File(Base):
    """Modelo de dados para arquivos armazenados no sistema."""
    
    __tablename__ = "files"
    
    id = Column(UUID(as_uuid=True), primary_key=True, default=uuid.uuid4)
    user_id = Column(String, nullable=False, index=True)
    filename = Column(String, nullable=False)
    stored_name = Column(String, nullable=False, unique=True)
    category = Column(String, nullable=False)
    mime_type = Column(String, nullable=False)
    size = Column(String, nullable=False)
    checksum = Column(String, nullable=False)
    tags = Column(ARRAY(String), nullable=True)
    description = Column(Text, nullable=True)
    is_public = Column(String, default="false", nullable=False)
    status = Column(String, default="completed", nullable=False)
    storage_path = Column(String, nullable=False)
    created_at = Column(DateTime, default=datetime.datetime.utcnow, nullable=False)
    updated_at = Column(
        DateTime, 
        default=datetime.datetime.utcnow, 
        onupdate=datetime.datetime.utcnow, 
        nullable=False
    )
    
    # Índices
    __table_args__ = (
        Index("ix_files_category", "category"),
        Index("ix_files_is_public", "is_public"),
        Index("ix_files_status", "status"),
    )
    
    def __repr__(self) -> str:
        """Representação em string do objeto.
        
        Returns:
            Representação em string
        """
        return f"<File(id={self.id}, filename={self.filename}, category={self.category})>"
