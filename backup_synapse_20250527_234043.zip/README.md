# SynapScale Backend

Consulte o README completo e expandido em `./synapse-backend/docs/README.md` para visão geral, arquitetura, instruções de instalação, exemplos de uso, monitoramento, troubleshooting e mais detalhes do projeto..
