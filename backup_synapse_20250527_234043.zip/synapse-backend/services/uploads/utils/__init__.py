"""Utilitários compartilhados."""
