# Guia de Contribuição

Consulte o arquivo principal em `./synapse-backend/docs/CONTRIBUTING.md` para as diretrizes completas de contribuição, padrões de código, fluxo de trabalho e ambiente de desenvolvimento do SynapScale.
