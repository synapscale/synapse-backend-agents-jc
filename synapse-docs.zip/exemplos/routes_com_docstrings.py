"""
Módulo de rotas para o serviço de uploads.

Este módulo implementa as rotas REST para o serviço de uploads do SynapScale,
permitindo o upload, listagem, recuperação e exclusão de arquivos.
"""

from fastapi import APIRouter, Depends, HTTPException, UploadFile, File, Form, Request
from fastapi.responses import JSONResponse, FileResponse
from typing import List, Optional
import os
import uuid
import logging
from datetime import datetime

from ..utils.auth import verify_token, get_token_scopes
from ..utils.storage import FileStorage
from ..utils.security import validate_file_type, sanitize_filename
from ..models.file import FileModel, FileResponse

# Configuração de logging
logger = logging.getLogger("uploads_routes")

# Inicialização do router
router = APIRouter(
    prefix="/api/uploads",
    tags=["uploads"],
    responses={
        401: {"description": "Não autorizado"},
        403: {"description": "Acesso proibido"},
        429: {"description": "Limite de requisições excedido"},
    },
)

# Inicialização do armazenamento de arquivos
storage = FileStorage(os.getenv("STORAGE_PATH", "/data/uploads"))

# Criar instância do rate limiter
rate_limiter = None  # Inicializado no módulo principal

@router.post("/", response_model=FileResponse, status_code=201)
async def upload_file(
    request: Request,
    file: UploadFile = File(...),
    description: Optional[str] = Form(None),
    token_data: dict = Depends(verify_token),
):
    """
    Faz upload de um arquivo para o sistema.
    
    Esta rota permite que usuários autenticados façam upload de arquivos,
    realizando validações de segurança como verificação de tipo MIME,
    tamanho máximo e sanitização de nomes de arquivo.
    
    Args:
        request: Objeto Request contendo informações da requisição
        file: Arquivo a ser enviado
        description: Descrição opcional do arquivo
        token_data: Dados do token JWT (injetado via dependency)
        
    Returns:
        FileResponse: Informações do arquivo enviado
        
    Raises:
        HTTPException: 
            - 400: Arquivo inválido (vazio, tipo não permitido, etc.)
            - 401: Token inválido ou expirado
            - 403: Escopo insuficiente
            - 413: Arquivo muito grande
    """
    # Verificar se o usuário tem permissão para upload
    scopes = get_token_scopes(token_data)
    if "uploads:write" not in scopes:
        logger.warning(f"Tentativa de upload sem permissão: {token_data.get('sub')}")
        raise HTTPException(
            status_code=403,
            detail="Permissão insuficiente para upload de arquivos",
        )
    
    try:
        # Verificar se o arquivo está vazio
        content = await file.read(1)
        if not content:
            raise HTTPException(status_code=400, detail="Arquivo vazio")
        await file.seek(0)
        
        # Validar tipo MIME e tamanho
        await validate_file_type(file)
        
        # Sanitizar nome do arquivo
        original_filename = file.filename
        safe_filename = sanitize_filename(original_filename)
        
        # Gerar ID único para o arquivo
        file_id = str(uuid.uuid4())
        
        # Salvar arquivo
        file_path = await storage.save_file(file, file_id, safe_filename)
        
        # Criar registro do arquivo
        file_size = os.path.getsize(file_path)
        file_record = FileModel(
            id=file_id,
            filename=safe_filename,
            original_filename=original_filename,
            size=file_size,
            mime_type=file.content_type,
            description=description,
            user_id=token_data.get("sub"),
            created_at=datetime.now(),
        )
        
        # Salvar metadados no banco de dados
        await storage.save_metadata(file_record)
        
        logger.info(f"Arquivo enviado com sucesso: {file_id} por {token_data.get('sub')}")
        
        # Retornar informações do arquivo
        return FileResponse(
            id=file_id,
            filename=safe_filename,
            size=file_size,
            mime_type=file.content_type,
            description=description,
            created_at=file_record.created_at,
            download_url=f"/api/uploads/{file_id}/download",
        )
        
    except HTTPException as e:
        # Repassar exceções HTTP
        logger.warning(f"Erro no upload: {e.detail}")
        raise
        
    except Exception as e:
        # Capturar outras exceções e retornar erro 500
        logger.error(f"Erro inesperado no upload: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Erro ao processar upload: {str(e)}",
        )

@router.get("/", response_model=List[FileResponse])
async def list_files(
    request: Request,
    page: int = 1,
    limit: int = 10,
    token_data: dict = Depends(verify_token),
):
    """
    Lista os arquivos do usuário.
    
    Esta rota retorna a lista paginada de arquivos do usuário autenticado.
    
    Args:
        request: Objeto Request contendo informações da requisição
        page: Número da página (começando em 1)
        limit: Número de itens por página
        token_data: Dados do token JWT (injetado via dependency)
        
    Returns:
        List[FileResponse]: Lista de arquivos do usuário
        
    Raises:
        HTTPException: 
            - 401: Token inválido ou expirado
            - 403: Escopo insuficiente
    """
    # Verificar se o usuário tem permissão para listar arquivos
    scopes = get_token_scopes(token_data)
    if "uploads:read" not in scopes:
        raise HTTPException(
            status_code=403,
            detail="Permissão insuficiente para listar arquivos",
        )
    
    try:
        # Obter ID do usuário
        user_id = token_data.get("sub")
        
        # Obter arquivos do usuário
        files = await storage.list_files(user_id, page, limit)
        
        # Converter para o formato de resposta
        response = [
            FileResponse(
                id=file.id,
                filename=file.filename,
                size=file.size,
                mime_type=file.mime_type,
                description=file.description,
                created_at=file.created_at,
                download_url=f"/api/uploads/{file.id}/download",
            )
            for file in files
        ]
        
        return response
        
    except Exception as e:
        logger.error(f"Erro ao listar arquivos: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Erro ao listar arquivos: {str(e)}",
        )

@router.get("/{file_id}", response_model=FileResponse)
async def get_file(
    file_id: str,
    token_data: dict = Depends(verify_token),
):
    """
    Obtém informações de um arquivo específico.
    
    Esta rota retorna os metadados de um arquivo específico.
    
    Args:
        file_id: ID do arquivo
        token_data: Dados do token JWT (injetado via dependency)
        
    Returns:
        FileResponse: Informações do arquivo
        
    Raises:
        HTTPException: 
            - 401: Token inválido ou expirado
            - 403: Escopo insuficiente ou arquivo de outro usuário
            - 404: Arquivo não encontrado
    """
    # Verificar se o usuário tem permissão para ler arquivos
    scopes = get_token_scopes(token_data)
    if "uploads:read" not in scopes:
        raise HTTPException(
            status_code=403,
            detail="Permissão insuficiente para acessar arquivos",
        )
    
    try:
        # Obter ID do usuário
        user_id = token_data.get("sub")
        
        # Obter arquivo
        file = await storage.get_file(file_id)
        
        # Verificar se o arquivo existe
        if not file:
            raise HTTPException(
                status_code=404,
                detail="Arquivo não encontrado",
            )
        
        # Verificar se o arquivo pertence ao usuário
        if file.user_id != user_id and "admin" not in scopes:
            raise HTTPException(
                status_code=403,
                detail="Acesso negado a este arquivo",
            )
        
        # Retornar informações do arquivo
        return FileResponse(
            id=file.id,
            filename=file.filename,
            size=file.size,
            mime_type=file.mime_type,
            description=file.description,
            created_at=file.created_at,
            download_url=f"/api/uploads/{file.id}/download",
        )
        
    except HTTPException:
        # Repassar exceções HTTP
        raise
        
    except Exception as e:
        logger.error(f"Erro ao obter arquivo: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Erro ao obter arquivo: {str(e)}",
        )

@router.get("/{file_id}/download")
async def download_file(
    file_id: str,
    token_data: dict = Depends(verify_token),
):
    """
    Faz download de um arquivo específico.
    
    Esta rota permite o download do conteúdo de um arquivo específico.
    
    Args:
        file_id: ID do arquivo
        token_data: Dados do token JWT (injetado via dependency)
        
    Returns:
        FileResponse: Conteúdo do arquivo para download
        
    Raises:
        HTTPException: 
            - 401: Token inválido ou expirado
            - 403: Escopo insuficiente ou arquivo de outro usuário
            - 404: Arquivo não encontrado
    """
    # Verificar se o usuário tem permissão para ler arquivos
    scopes = get_token_scopes(token_data)
    if "uploads:read" not in scopes:
        raise HTTPException(
            status_code=403,
            detail="Permissão insuficiente para baixar arquivos",
        )
    
    try:
        # Obter ID do usuário
        user_id = token_data.get("sub")
        
        # Obter arquivo
        file = await storage.get_file(file_id)
        
        # Verificar se o arquivo existe
        if not file:
            raise HTTPException(
                status_code=404,
                detail="Arquivo não encontrado",
            )
        
        # Verificar se o arquivo pertence ao usuário
        if file.user_id != user_id and "admin" not in scopes:
            raise HTTPException(
                status_code=403,
                detail="Acesso negado a este arquivo",
            )
        
        # Obter caminho do arquivo
        file_path = storage.get_file_path(file_id, file.filename)
        
        # Verificar se o arquivo existe no sistema de arquivos
        if not os.path.exists(file_path):
            raise HTTPException(
                status_code=404,
                detail="Arquivo não encontrado no sistema",
            )
        
        # Registrar download
        logger.info(f"Download de arquivo: {file_id} por {user_id}")
        
        # Retornar arquivo para download
        return FileResponse(
            path=file_path,
            filename=file.filename,
            media_type=file.mime_type,
        )
        
    except HTTPException:
        # Repassar exceções HTTP
        raise
        
    except Exception as e:
        logger.error(f"Erro ao baixar arquivo: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Erro ao baixar arquivo: {str(e)}",
        )

@router.delete("/{file_id}", status_code=204)
async def delete_file(
    file_id: str,
    token_data: dict = Depends(verify_token),
):
    """
    Exclui um arquivo específico.
    
    Esta rota permite a exclusão de um arquivo específico.
    
    Args:
        file_id: ID do arquivo
        token_data: Dados do token JWT (injetado via dependency)
        
    Returns:
        None: Resposta vazia com status 204
        
    Raises:
        HTTPException: 
            - 401: Token inválido ou expirado
            - 403: Escopo insuficiente ou arquivo de outro usuário
            - 404: Arquivo não encontrado
    """
    # Verificar se o usuário tem permissão para excluir arquivos
    scopes = get_token_scopes(token_data)
    if "uploads:write" not in scopes:
        raise HTTPException(
            status_code=403,
            detail="Permissão insuficiente para excluir arquivos",
        )
    
    try:
        # Obter ID do usuário
        user_id = token_data.get("sub")
        
        # Obter arquivo
        file = await storage.get_file(file_id)
        
        # Verificar se o arquivo existe
        if not file:
            raise HTTPException(
                status_code=404,
                detail="Arquivo não encontrado",
            )
        
        # Verificar se o arquivo pertence ao usuário
        if file.user_id != user_id and "admin" not in scopes:
            raise HTTPException(
                status_code=403,
                detail="Acesso negado a este arquivo",
            )
        
        # Excluir arquivo
        await storage.delete_file(file_id, file.filename)
        
        logger.info(f"Arquivo excluído: {file_id} por {user_id}")
        
        # Retornar resposta vazia
        return None
        
    except HTTPException:
        # Repassar exceções HTTP
        raise
        
    except Exception as e:
        logger.error(f"Erro ao excluir arquivo: {str(e)}", exc_info=True)
        raise HTTPException(
            status_code=500,
            detail=f"Erro ao excluir arquivo: {str(e)}",
        )
