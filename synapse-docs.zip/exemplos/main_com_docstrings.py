"""
Módulo principal do serviço de uploads.

Este módulo implementa o serviço de uploads do SynapScale, responsável por
gerenciar o upload, armazenamento e recuperação de arquivos de forma segura.
Inclui validação rigorosa de tipos MIME, sanitização de nomes de arquivos e
controle de acesso baseado em escopos.
"""

from fastapi import FastAPI, HTTPException, Depends, UploadFile, File, Form, Request
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, FileResponse
import os
import uuid
import logging
import aiofiles
from datetime import datetime
from typing import List, Optional

from .routes import uploads
from .utils.auth import verify_token, get_token_scopes
from .utils.storage import FileStorage
from .utils.security import RateLimiter

# Configuração de logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger("uploads_service")

# Inicialização da aplicação
app = FastAPI(
    title="SynapScale Uploads Service",
    description="Serviço para gerenciamento seguro de uploads de arquivos",
    version="1.0.0",
)

# Configuração de CORS
origins = os.getenv("CORS_ORIGINS", "http://localhost:3000").split(",")
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

# Inicialização do armazenamento de arquivos
storage = FileStorage(os.getenv("STORAGE_PATH", "/data/uploads"))

# Inicialização do rate limiter
rate_limiter = RateLimiter(
    max_requests=int(os.getenv("RATE_LIMIT_MAX_REQUESTS", "100")),
    time_window=int(os.getenv("RATE_LIMIT_TIME_WINDOW", "3600")),
)

# Middleware para rate limiting
@app.middleware("http")
async def rate_limiting_middleware(request: Request, call_next):
    """
    Middleware para limitar a taxa de requisições por usuário/IP.
    
    Args:
        request: Objeto Request contendo informações da requisição
        call_next: Função para chamar o próximo middleware ou rota
        
    Returns:
        Response: Resposta da API ou erro 429 se o limite for excedido
        
    Raises:
        HTTPException: Quando o limite de requisições é excedido
    """
    try:
        await rate_limiter(request)
        response = await call_next(request)
        return response
    except HTTPException as e:
        return JSONResponse(
            status_code=e.status_code,
            content={"error": e.detail, "error_code": "rate_limit_exceeded"},
        )

# Incluir rotas
app.include_router(uploads.router)

@app.get("/health")
async def health_check():
    """
    Verifica a saúde do serviço de uploads.
    
    Returns:
        dict: Status do serviço e informações adicionais
    """
    return {
        "status": "healthy",
        "service": "uploads",
        "version": "1.0.0",
        "timestamp": datetime.now().isoformat(),
    }

@app.on_event("startup")
async def startup_event():
    """
    Evento executado na inicialização do serviço.
    Garante que o diretório de armazenamento exista.
    """
    logger.info("Iniciando serviço de uploads")
    storage.ensure_storage_exists()
    
@app.on_event("shutdown")
async def shutdown_event():
    """
    Evento executado no desligamento do serviço.
    Realiza limpeza de recursos se necessário.
    """
    logger.info("Desligando serviço de uploads")
