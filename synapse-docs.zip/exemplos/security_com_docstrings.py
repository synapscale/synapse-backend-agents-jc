"""
Módulo de utilitários para segurança do serviço de uploads.

Este módulo implementa funcionalidades de segurança para o serviço de uploads,
incluindo rate limiting, validação de tipos de arquivo e sanitização de nomes
de arquivos.
"""

from fastapi import Request, HTTPException, UploadFile
import time
import re
import os
import magic
from typing import Dict, List, Set, Optional
import logging

# Configuração de logging
logger = logging.getLogger("uploads_security")

# Configurações de segurança
MAX_FILE_SIZE = int(os.getenv("MAX_FILE_SIZE", "104857600"))  # 100MB por padrão
ALLOWED_MIME_TYPES = {
    # Documentos
    "application/pdf",
    "application/msword",
    "application/vnd.openxmlformats-officedocument.wordprocessingml.document",
    "application/vnd.ms-excel",
    "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
    "application/vnd.ms-powerpoint",
    "application/vnd.openxmlformats-officedocument.presentationml.presentation",
    "text/plain",
    "text/csv",
    "text/markdown",
    
    # Imagens
    "image/jpeg",
    "image/png",
    "image/gif",
    "image/svg+xml",
    "image/webp",
    
    # Áudio
    "audio/mpeg",
    "audio/wav",
    "audio/ogg",
    
    # Vídeo
    "video/mp4",
    "video/webm",
    "video/ogg",
    
    # Arquivos compactados
    "application/zip",
    "application/x-rar-compressed",
    "application/gzip",
}

class RateLimiter:
    """
    Implementa limitação de taxa de requisições por usuário ou IP.
    
    Esta classe mantém um registro de requisições por usuário/IP e bloqueia
    requisições quando o limite é atingido dentro de uma janela de tempo.
    
    Attributes:
        max_requests: Número máximo de requisições permitidas na janela de tempo
        time_window: Janela de tempo em segundos
        request_records: Dicionário com registros de requisições por usuário/IP
    """
    
    def __init__(self, max_requests: int = 100, time_window: int = 3600):
        """
        Inicializa o rate limiter.
        
        Args:
            max_requests: Número máximo de requisições permitidas na janela de tempo
            time_window: Janela de tempo em segundos
        """
        self.max_requests = max_requests
        self.time_window = time_window
        self.request_records: Dict[str, List[float]] = {}
        logger.info(f"Rate limiter inicializado: {max_requests} req/{time_window}s")
    
    async def __call__(self, request: Request):
        """
        Verifica se a requisição excede o limite de taxa.
        
        Args:
            request: Objeto Request contendo informações da requisição
            
        Raises:
            HTTPException: Quando o limite de requisições é excedido
        """
        # Obter identificador do cliente (token ou IP)
        client_id = self._get_client_id(request)
        
        # Obter timestamp atual
        current_time = time.time()
        
        # Inicializar registro se não existir
        if client_id not in self.request_records:
            self.request_records[client_id] = []
        
        # Remover timestamps antigos (fora da janela de tempo)
        self.request_records[client_id] = [
            ts for ts in self.request_records[client_id]
            if current_time - ts < self.time_window
        ]
        
        # Verificar se excede o limite
        if len(self.request_records[client_id]) >= self.max_requests:
            oldest_request = min(self.request_records[client_id])
            retry_after = int(self.time_window - (current_time - oldest_request))
            
            logger.warning(f"Rate limit excedido para {client_id}, retry após {retry_after}s")
            
            # Lançar HTTPException com status 429 (Too Many Requests)
            raise HTTPException(
                status_code=429,
                detail=f"Limite de requisições excedido. Tente novamente em {retry_after} segundos.",
                headers={"Retry-After": str(retry_after)},
            )
        
        # Registrar timestamp da requisição atual
        self.request_records[client_id].append(current_time)
    
    def _get_client_id(self, request: Request) -> str:
        """
        Obtém um identificador único para o cliente.
        
        Tenta usar o token JWT se disponível, caso contrário usa o IP.
        
        Args:
            request: Objeto Request contendo informações da requisição
            
        Returns:
            str: Identificador único do cliente
        """
        # Tentar obter token do header Authorization
        auth_header = request.headers.get("Authorization")
        if auth_header and auth_header.startswith("Bearer "):
            return auth_header[7:]  # Remove "Bearer " do início
        
        # Usar IP como fallback
        forwarded_for = request.headers.get("X-Forwarded-For")
        if forwarded_for:
            # Pegar o primeiro IP (cliente original) se houver vários
            return forwarded_for.split(",")[0].strip()
        
        # Usar IP direto da requisição
        return request.client.host if request.client else "unknown"

async def validate_file_type(file: UploadFile, max_size: Optional[int] = None) -> None:
    """
    Valida o tipo e tamanho do arquivo.
    
    Verifica se o arquivo tem um tipo MIME permitido e não excede o tamanho máximo.
    
    Args:
        file: Arquivo a ser validado
        max_size: Tamanho máximo em bytes (usa o valor global se não especificado)
        
    Raises:
        HTTPException: 
            - 400: Tipo de arquivo não permitido
            - 413: Arquivo muito grande
    """
    if max_size is None:
        max_size = MAX_FILE_SIZE
    
    # Ler início do arquivo para detecção de tipo
    content = await file.read(2048)
    await file.seek(0)
    
    # Detectar tipo MIME real usando python-magic
    mime_type = magic.from_buffer(content, mime=True)
    
    # Verificar se o tipo MIME é permitido
    if mime_type not in ALLOWED_MIME_TYPES:
        logger.warning(f"Tipo de arquivo não permitido: {mime_type}")
        raise HTTPException(
            status_code=400,
            detail=f"Tipo de arquivo não permitido: {mime_type}",
        )
    
    # Verificar tamanho do arquivo
    file_size = 0
    chunk_size = 8192
    
    while True:
        chunk = await file.read(chunk_size)
        if not chunk:
            break
        file_size += len(chunk)
        if file_size > max_size:
            await file.seek(0)
            logger.warning(f"Arquivo muito grande: {file_size} bytes (máx: {max_size})")
            raise HTTPException(
                status_code=413,
                detail=f"Arquivo muito grande. Tamanho máximo: {max_size/1024/1024:.1f}MB",
            )
    
    # Voltar ao início do arquivo
    await file.seek(0)
    
    # Atualizar content_type com o tipo MIME real
    file.content_type = mime_type
    logger.info(f"Arquivo validado: {file.filename}, tipo: {mime_type}, tamanho: {file_size}")

def sanitize_filename(filename: str) -> str:
    """
    Sanitiza o nome do arquivo para evitar injeção de caminho e caracteres inválidos.
    
    Args:
        filename: Nome original do arquivo
        
    Returns:
        str: Nome sanitizado do arquivo
    """
    if not filename:
        return "unnamed_file"
    
    # Remover caminhos (pegar apenas o nome do arquivo)
    filename = os.path.basename(filename)
    
    # Remover caracteres especiais e espaços
    # Manter apenas letras, números, ponto, hífen e underscore
    sanitized = re.sub(r'[^\w\.-]', '_', filename)
    
    # Limitar comprimento
    if len(sanitized) > 255:
        name, ext = os.path.splitext(sanitized)
        sanitized = name[:255-len(ext)] + ext
    
    # Garantir que não comece com ponto (arquivo oculto)
    if sanitized.startswith('.'):
        sanitized = 'f' + sanitized
    
    logger.debug(f"Nome sanitizado: {filename} -> {sanitized}")
    return sanitized
