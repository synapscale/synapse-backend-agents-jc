"""Inicialização do pacote de modelos.

Este módulo exporta os modelos de dados do sistema.
"""

from .file import File

__all__ = ["File"]
