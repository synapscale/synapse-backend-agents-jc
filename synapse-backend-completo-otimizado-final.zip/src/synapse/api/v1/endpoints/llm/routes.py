"""Endpoints para integração com modelos de linguagem (LLMs).

Este módulo contém todas as rotas para interação com diferentes 
provedores de LLM, incluindo geração de texto, contagem de tokens
e listagem de modelos disponíveis.
"""

from typing import List, Optional, Dict, Any, Union

from fastapi import APIRouter, Depends, HTTPException, Path, Query, Body
from fastapi.responses import StreamingResponse

from synapse.core.auth.jwt import get_current_user
from synapse.schemas.llm import (
    LLMGenerateRequest, 
    LLMGenerateResponse,
    LLMCountTokensRequest,
    LLMCountTokensResponse,
    LLMModelInfo,
    LLMProviderInfo
)
from synapse.core.llm.factory import LLMFactory

router = APIRouter(prefix="/llm", tags=["llm"])

@router.post(
    "/generate",
    response_model=LLMGenerateResponse,
    summary="Generate Text",
    description="""
## 📝 Descrição

Gera texto a partir de um prompt usando o provedor padrão ou especificado.

## 🔍 Detalhes Importantes

Este endpoint permite gerar texto usando diferentes provedores de LLM, com controle granular sobre os parâmetros de geração. Se nenhum provedor for especificado, o sistema usará o provedor padrão (geralmente OpenAI).

## 📊 Tabela de Provedores Suportados

| Provedor | Descrição | Casos de Uso Recomendados | Modelos Principais |
|----------|-----------|---------------------------|-------------------|
| OpenAI | Modelos GPT da OpenAI | Geração de texto de alta qualidade, análise, classificação | gpt-4, gpt-4-turbo, gpt-3.5-turbo |
| Claude | Modelos Claude da Anthropic | Raciocínio ético, explicações detalhadas, contexto longo | claude-3-opus, claude-3-sonnet, claude-3-haiku |
| Gemini | Modelos Gemini do Google | Tarefas multimodais, análise de dados, código | gemini-pro, gemini-pro-vision, gemini-ultra |
| Llama | Modelos Llama da Meta | Alternativa open-source, personalização | llama-3-70b, llama-3-8b |
| Grok | Modelos Grok da xAI | Respostas criativas, conhecimento atualizado | grok-1, grok-2 |
| DeepSeek | Modelos DeepSeek | Especializado em código, matemática | deepseek-coder, deepseek-math |

## ⚙️ Parâmetros de Controle

* **temperature**: Controla aleatoriedade (0.0-2.0)
* **top_p**: Controla diversidade via amostragem nucleus (0.0-1.0)
* **max_tokens**: Limita tamanho da resposta
* **frequency_penalty**: Reduz repetições de palavras (-2.0 a 2.0)
* **presence_penalty**: Incentiva novos tópicos (-2.0 a 2.0)

## 📋 Exemplos de Uso

### Geração básica com OpenAI
```json
{
  "prompt": "Explique o conceito de aprendizado de máquina",
  "model": "gpt-4-turbo",
  "temperature": 0.7
}
```

### Geração com Claude para contexto longo
```json
{
  "prompt": "Analise este documento extenso: [documento longo aqui]",
  "provider": "claude",
  "model": "claude-3-opus",
  "temperature": 0.2,
  "max_tokens": 2000
}
```

### Geração de código com DeepSeek
```json
{
  "prompt": "Escreva uma função Python para ordenar uma lista de dicionários por uma chave específica",
  "provider": "deepseek",
  "model": "deepseek-coder",
  "temperature": 0.1
}
```

## 📌 Notas Adicionais

* Para obter melhores resultados, forneça prompts claros e específicos
* Ajuste a temperature para controlar criatividade vs. precisão
* Use max_tokens para limitar o tamanho da resposta
    """
)
async def generate_text(
    request: LLMGenerateRequest,
    current_user: Dict = Depends(get_current_user)
) -> LLMGenerateResponse:
    """
    Gera texto a partir de um prompt usando o provedor padrão ou especificado.
    
    - **prompt**: Texto de entrada para o modelo (obrigatório)
    - **provider**: Provedor LLM a ser usado (opcional, padrão: openai)
    - **model**: Modelo específico do provedor (opcional)
    - **temperature**: Controle de aleatoriedade (0.0-1.0, padrão: 0.7)
    - **max_tokens**: Limite de tokens na resposta (padrão: 1000)
    - **top_p**: Controle de diversidade (0.0-1.0, padrão: 1.0)
    - **frequency_penalty**: Reduz repetições (-2.0 a 2.0, padrão: 0.0)
    - **presence_penalty**: Incentiva novos tópicos (-2.0 a 2.0, padrão: 0.0)
    """
    try:
        llm = LLMFactory.get_llm(request.provider)
        response = await llm.generate_text(request)
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao gerar texto: {str(e)}")

@router.post(
    "/count-tokens",
    response_model=LLMCountTokensResponse,
    summary="Count Tokens",
    description="""
## 📝 Descrição

Conta o número de tokens em um texto usando o tokenizador do provedor especificado.

## 🔍 Detalhes Importantes

Este endpoint permite contar tokens em um texto usando o tokenizador do provedor especificado. Isso é útil para estimar custos e garantir que o texto não exceda os limites de contexto do modelo.

## 📊 Tokenização por Provedor

| Provedor | Método de Tokenização | Características |
|----------|----------------------|-----------------|
| OpenAI | tiktoken | Tokenização baseada em BPE, específica por modelo |
| Claude | claude-tokenizer | Tokenização proprietária da Anthropic |
| Gemini | SentencePiece | Tokenização baseada em subpalavras |
| Llama | LlamaTokenizer | Tokenização específica para modelos Llama |

## 📋 Exemplos de Uso

### Contagem básica com OpenAI
```json
{
  "text": "Este é um exemplo de texto para contar tokens",
  "provider": "openai",
  "model": "gpt-4"
}
```

### Contagem com Claude
```json
{
  "text": "Texto longo para análise de tokens...",
  "provider": "claude",
  "model": "claude-3-opus"
}
```

## 📌 Notas Adicionais

* Diferentes provedores usam diferentes métodos de tokenização
* O mesmo texto pode ter contagens diferentes em provedores diferentes
* Use esta função para estimar custos e garantir que o texto não exceda os limites do modelo
    """
)
async def count_tokens(
    request: LLMCountTokensRequest,
    current_user: Dict = Depends(get_current_user)
) -> LLMCountTokensResponse:
    """
    Conta o número de tokens em um texto usando o tokenizador do provedor especificado.
    
    - **text**: Texto para contar tokens (obrigatório)
    - **provider**: Provedor LLM a ser usado (opcional, padrão: openai)
    - **model**: Modelo específico do provedor (opcional)
    """
    try:
        llm = LLMFactory.get_llm(request.provider)
        response = await llm.count_tokens(request)
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao contar tokens: {str(e)}")

@router.get(
    "/models",
    response_model=List[LLMModelInfo],
    summary="List Models",
    description="""
## 📝 Descrição

Lista todos os modelos LLM disponíveis em todos os provedores suportados.

## 🔍 Detalhes Importantes

Este endpoint retorna informações detalhadas sobre todos os modelos disponíveis, incluindo capacidades, tamanho de contexto e recomendações de uso.

## 📊 Categorias de Modelos

| Categoria | Descrição | Exemplos |
|-----------|-----------|----------|
| Texto | Modelos focados em geração de texto | GPT-3.5, Claude Haiku |
| Visão | Modelos com capacidades multimodais | GPT-4o, Claude Opus, Gemini Pro Vision |
| Código | Modelos otimizados para programação | DeepSeek Coder, Llama Code |
| Raciocínio | Modelos com foco em raciocínio lógico | Claude Opus, Gemini Ultra |

## 📋 Parâmetros de Consulta

* **provider**: Filtra modelos por provedor específico
* **capability**: Filtra modelos por capacidade (text, vision, code, etc.)
* **min_context**: Filtra modelos com contexto mínimo especificado

## 📌 Notas Adicionais

* Verifique regularmente por novos modelos adicionados
* Escolha o modelo adequado para sua tarefa específica
* Considere o equilíbrio entre qualidade, velocidade e custo
    """
)
async def list_models(
    provider: Optional[str] = Query(None, description="Filtrar por provedor específico"),
    capability: Optional[str] = Query(None, description="Filtrar por capacidade (text, vision, code, etc.)"),
    current_user: Dict = Depends(get_current_user)
) -> List[LLMModelInfo]:
    """
    Lista todos os modelos LLM disponíveis em todos os provedores suportados.
    
    - **provider**: Filtrar por provedor específico (opcional)
    - **capability**: Filtrar por capacidade (opcional)
    """
    try:
        models = []
        for provider_id in LLMFactory.get_available_providers():
            if provider and provider != provider_id:
                continue
                
            llm = LLMFactory.get_llm(provider_id)
            provider_models = await llm.list_models()
            
            if capability:
                provider_models = [m for m in provider_models if capability in m.capabilities]
                
            models.extend(provider_models)
            
        return models
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao listar modelos: {str(e)}")

@router.get(
    "/providers",
    response_model=List[LLMProviderInfo],
    summary="List Providers",
    description="""
## 📝 Descrição

Lista todos os provedores LLM disponíveis no sistema.

## 🔍 Detalhes Importantes

Este endpoint retorna informações sobre todos os provedores LLM integrados, incluindo status, número de modelos e links para documentação.

## 📊 Provedores Suportados

| Provedor | Especialidade | Documentação |
|----------|--------------|--------------|
| OpenAI | Modelos GPT de alta qualidade | [Documentação OpenAI](https://platform.openai.com/docs) |
| Claude | Modelos com raciocínio avançado | [Documentação Claude](https://docs.anthropic.com) |
| Gemini | Modelos multimodais do Google | [Documentação Gemini](https://ai.google.dev/docs) |
| Llama | Modelos open-source da Meta | [Documentação Llama](https://llama.meta.com/docs) |
| Grok | Modelos da xAI | [Documentação Grok](https://grok.x.ai/docs) |
| DeepSeek | Modelos especializados em código | [Documentação DeepSeek](https://deepseek.ai/docs) |

## 📌 Notas Adicionais

* Verifique o status de cada provedor antes de usar
* Alguns provedores podem exigir configurações adicionais
* Consulte a documentação específica para detalhes de cada provedor
    """
)
async def list_providers(
    current_user: Dict = Depends(get_current_user)
) -> List[LLMProviderInfo]:
    """
    Lista todos os provedores LLM disponíveis no sistema.
    """
    try:
        providers = []
        for provider_id in LLMFactory.get_available_providers():
            llm = LLMFactory.get_llm(provider_id)
            provider_info = await llm.get_provider_info()
            providers.append(provider_info)
            
        return providers
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao listar provedores: {str(e)}")

@router.post(
    "/{provider}/generate",
    response_model=LLMGenerateResponse,
    summary="Generate Text With Provider",
    description="""
## 📝 Descrição

Gera texto usando um provedor LLM específico.

## 🔍 Detalhes Importantes

Este endpoint é uma variante do endpoint de geração principal, mas com o provedor especificado diretamente na URL. Útil para integrações que precisam garantir o uso de um provedor específico.

## 📊 Provedores Disponíveis

* **openai**: Modelos GPT da OpenAI
* **claude**: Modelos Claude da Anthropic
* **gemini**: Modelos Gemini do Google
* **llama**: Modelos Llama da Meta
* **grok**: Modelos Grok da xAI
* **deepseek**: Modelos DeepSeek
* **tess**: Orquestrador de múltiplos modelos

## 📋 Exemplos de Uso

### Geração com OpenAI
```
POST /api/v1/llm/openai/generate
```
```json
{
  "prompt": "Explique o conceito de aprendizado de máquina",
  "model": "gpt-4-turbo",
  "temperature": 0.7
}
```

### Geração com Claude
```
POST /api/v1/llm/claude/generate
```
```json
{
  "prompt": "Analise este documento extenso: [documento longo aqui]",
  "model": "claude-3-opus",
  "temperature": 0.2,
  "max_tokens": 2000
}
```

## 📌 Notas Adicionais

* O parâmetro `provider` no corpo da requisição é ignorado, pois o provedor é especificado na URL
* Todos os outros parâmetros funcionam da mesma forma que no endpoint principal
    """
)
async def generate_text_with_provider(
    provider: str = Path(..., description="Provedor LLM a ser usado"),
    request: LLMGenerateRequest = Body(...),
    current_user: Dict = Depends(get_current_user)
) -> LLMGenerateResponse:
    """
    Gera texto usando um provedor LLM específico.
    
    - **provider**: Provedor LLM a ser usado (na URL)
    - **prompt**: Texto de entrada para o modelo (obrigatório)
    - **model**: Modelo específico do provedor (opcional)
    - **temperature**: Controle de aleatoriedade (0.0-1.0, padrão: 0.7)
    - **max_tokens**: Limite de tokens na resposta (padrão: 1000)
    """
    try:
        # Sobrescreve o provedor na requisição com o da URL
        request_dict = request.dict()
        request_dict["provider"] = provider
        provider_request = LLMGenerateRequest(**request_dict)
        
        llm = LLMFactory.get_llm(provider)
        response = await llm.generate_text(provider_request)
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao gerar texto com {provider}: {str(e)}")

@router.post(
    "/{provider}/count-tokens",
    response_model=LLMCountTokensResponse,
    summary="Count Tokens With Provider",
    description="""
## 📝 Descrição

Conta tokens em um texto usando um provedor LLM específico.

## 🔍 Detalhes Importantes

Este endpoint é uma variante do endpoint de contagem de tokens principal, mas com o provedor especificado diretamente na URL. Útil para integrações que precisam garantir o uso de um tokenizador específico.

## 📊 Provedores e Tokenizadores

| Provedor | Tokenizador | Características |
|----------|------------|-----------------|
| OpenAI | tiktoken | Tokenização eficiente baseada em BPE |
| Claude | claude-tokenizer | Otimizado para modelos Claude |
| Gemini | SentencePiece | Tokenização baseada em subpalavras |
| Llama | LlamaTokenizer | Específico para modelos Llama |

## 📋 Exemplos de Uso

### Contagem com OpenAI
```
POST /api/v1/llm/openai/count-tokens
```
```json
{
  "text": "Este é um exemplo de texto para contar tokens",
  "model": "gpt-4"
}
```

### Contagem com Claude
```
POST /api/v1/llm/claude/count-tokens
```
```json
{
  "text": "Texto longo para análise de tokens...",
  "model": "claude-3-opus"
}
```

## 📌 Notas Adicionais

* O parâmetro `provider` no corpo da requisição é ignorado, pois o provedor é especificado na URL
* Diferentes provedores podem retornar contagens diferentes para o mesmo texto
    """
)
async def count_tokens_with_provider(
    provider: str = Path(..., description="Provedor LLM a ser usado"),
    request: LLMCountTokensRequest = Body(...),
    current_user: Dict = Depends(get_current_user)
) -> LLMCountTokensResponse:
    """
    Conta tokens em um texto usando um provedor LLM específico.
    
    - **provider**: Provedor LLM a ser usado (na URL)
    - **text**: Texto para contar tokens (obrigatório)
    - **model**: Modelo específico do provedor (opcional)
    """
    try:
        # Sobrescreve o provedor na requisição com o da URL
        request_dict = request.dict()
        request_dict["provider"] = provider
        provider_request = LLMCountTokensRequest(**request_dict)
        
        llm = LLMFactory.get_llm(provider)
        response = await llm.count_tokens(provider_request)
        return response
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao contar tokens com {provider}: {str(e)}")

@router.get(
    "/{provider}/models",
    response_model=List[LLMModelInfo],
    summary="List Models For Provider",
    description="""
## 📝 Descrição

Lista todos os modelos disponíveis para um provedor LLM específico.

## 🔍 Detalhes Importantes

Este endpoint retorna informações detalhadas sobre todos os modelos disponíveis para um provedor específico, incluindo capacidades, tamanho de contexto e recomendações de uso.

## 📊 Modelos por Provedor

### OpenAI
* **GPT-4o**: Modelo multimodal mais avançado (texto e visão)
* **GPT-4-turbo**: Modelo de texto de alta qualidade com contexto extenso
* **GPT-3.5-turbo**: Modelo balanceado entre custo e qualidade

### Claude
* **Claude 3 Opus**: Modelo mais poderoso da Anthropic
* **Claude 3 Sonnet**: Equilíbrio entre performance e velocidade
* **Claude 3 Haiku**: Modelo mais rápido e econômico

### Gemini
* **Gemini 1.5 Pro**: Modelo multimodal avançado
* **Gemini 1.5 Flash**: Versão mais rápida e econômica

### Llama
* **Llama 3 70B**: Modelo mais poderoso da família Llama
* **Llama 3 8B**: Versão mais leve e rápida

## 📋 Parâmetros de Consulta

* **capability**: Filtra modelos por capacidade (text, vision, code, etc.)
* **min_context**: Filtra modelos com contexto mínimo especificado

## 📌 Notas Adicionais

* Novos modelos são adicionados regularmente
* Verifique a documentação do provedor para detalhes específicos
* Considere o equilíbrio entre qualidade, velocidade e custo ao escolher um modelo
    """
)
async def list_models_for_provider(
    provider: str = Path(..., description="Provedor LLM específico"),
    capability: Optional[str] = Query(None, description="Filtrar por capacidade (text, vision, code, etc.)"),
    current_user: Dict = Depends(get_current_user)
) -> List[LLMModelInfo]:
    """
    Lista todos os modelos disponíveis para um provedor LLM específico.
    
    - **provider**: Provedor LLM específico (na URL)
    - **capability**: Filtrar por capacidade (opcional)
    """
    try:
        llm = LLMFactory.get_llm(provider)
        models = await llm.list_models()
        
        if capability:
            models = [m for m in models if capability in m.capabilities]
            
        return models
    except Exception as e:
        raise HTTPException(status_code=500, detail=f"Erro ao listar modelos para {provider}: {str(e)}")
