"""Inicialização do pacote API v1.

Este módulo exporta o roteador principal da API v1.
"""

from .router import router

__all__ = ["router"]
