"""Aplicação principal do backend SynapScale.

Este módulo configura e inicializa a aplicação FastAPI, incluindo
rotas, middlewares, documentação e serviços essenciais.
"""

import os
from fastapi import FastAPI, Request, Depends
from fastapi.middleware.cors import CORSMiddleware
from fastapi.responses import JSONResponse, HTMLResponse
from fastapi.staticfiles import StaticFiles
from fastapi.openapi.utils import get_openapi

from synapse.api.v1.router import router as api_router
from synapse.core.auth.jwt import get_current_user
from synapse.middlewares.rate_limiting import setup_rate_limiting
from synapse.logging import setup_logging, get_logger
from synapse.config import settings

# Configuração de logging
setup_logging()
logger = get_logger(__name__)

# Inicialização da aplicação FastAPI
app = FastAPI(
    title="SynapScale Backend API",
    description="""
# SynapScale Backend API

API completa para integração com múltiplos provedores de LLM, gerenciamento de arquivos e processamento de dados.

## 📚 Recursos Principais

* **Integração Multi-LLM**: Acesso unificado a diversos provedores de LLM (OpenAI, Claude, Gemini, etc.)
* **Gerenciamento de Arquivos**: Upload, download e manipulação de arquivos
* **Processamento de Dados**: Análise e transformação de dados

## 🔐 Autenticação

A API utiliza autenticação via Bearer Token (JWT). Inclua o token no header `Authorization` de todas as requisições:

```
Authorization: Bearer seu_token_jwt
```

Para obter um token, utilize o endpoint de autenticação.

## 🚀 Provedores LLM Suportados

| Provedor | Modelos Disponíveis | Capacidades |
|----------|-------------------|------------------------|
| OpenAI   | GPT-4o, GPT-4-turbo, GPT-3.5-turbo | Text, Vision, Function Calling |
| Claude   | Claude 3 Opus, Sonnet, Haiku | Text, Vision, Reasoning |
| Gemini   | Gemini 1.5 Pro, Flash | Text, Vision, Code |
| Llama    | Llama 3 70B, 8B, Llama 2 70B | Text Generation |
| Grok     | Grok-1 | Text, Function Calling |
| DeepSeek | DeepSeek Chat, Coder | Text, Code Generation |
| Tess     | Múltiplos via orquestração | Text, Reasoning |

## 📋 Parâmetros Comuns

* `prompt`: Texto de entrada para o modelo (obrigatório)
* `provider`: Provedor LLM a ser usado (opcional, padrão: openai)
* `model`: Modelo específico do provedor (opcional)
* `temperature`: Controle de aleatoriedade (0.0-1.0, padrão: 0.7)
* `max_tokens`: Limite de tokens na resposta (padrão: 1000)

Consulte a documentação detalhada para mais informações sobre parâmetros específicos por provedor.
    """,
    version="1.0.0",
    docs_url=None,
    redoc_url=None,
)

# Configuração de CORS
origins = ["*"]  # Em produção, especifique origens permitidas
app.add_middleware(
    CORSMiddleware,
    allow_origins=origins,
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)
logger.info(f"CORS configurado com origens: {origins}")

# Configuração do middleware de rate limiting
setup_rate_limiting(app)
logger.info("Middleware de rate limiting configurado")

# Montagem de rotas da API
app.include_router(api_router, prefix="/api/v1")

# Montagem de arquivos estáticos
app.mount("/static", StaticFiles(directory=os.path.join(os.path.dirname(__file__), "static")), name="static")

# HTML personalizado para documentação Swagger
SWAGGER_UI_HTML = """
<!DOCTYPE html>
<html lang="pt-BR">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>SynapScale API - Documentação Interativa</title>
    <link rel="stylesheet" type="text/css" href="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5.9.0/swagger-ui.css">
    <style>
        /* Estilos diretos para garantir aplicação */
        body {
            margin: 0;
            padding: 0;
            font-family: 'Segoe UI', Roboto, 'Helvetica Neue', Arial, sans-serif;
            background-color: #FFFFFF;
            color: #212121;
        }
        
        .swagger-ui .topbar {
            background-color: #000000;
            padding: 15px 0;
        }
        
        .swagger-ui .info {
            margin: 30px 0;
        }
        
        .swagger-ui .info .title {
            color: #000000 !important;
            font-size: 36px !important;
            font-weight: 700 !important;
            margin: 0 0 20px 0 !important;
        }
        
        .swagger-ui .info .title small.version-stamp {
            background-color: #FF4500 !important;
            color: white !important;
            padding: 5px 10px !important;
            border-radius: 4px !important;
            margin-left: 10px !important;
        }
        
        .swagger-ui .info .title small.version-stamp pre {
            color: white !important;
        }
        
        .swagger-ui .opblock-tag {
            font-size: 20px !important;
            margin: 20px 0 10px 0 !important;
            padding: 10px 20px !important;
            border-left: 4px solid #4CAF50 !important;
            background-color: #f8f9fa !important;
            border-radius: 0 4px 4px 0 !important;
        }
        
        .swagger-ui .opblock {
            margin: 0 0 15px 0 !important;
            border-radius: 4px !important;
            box-shadow: 0 2px 5px rgba(0, 0, 0, 0.1) !important;
            overflow: hidden !important;
        }
        
        .swagger-ui .opblock .opblock-summary {
            padding: 10px !important;
        }
        
        .swagger-ui .opblock .opblock-summary-method {
            border-radius: 4px !important;
            padding: 8px 12px !important;
            min-width: 80px !important;
            text-align: center !important;
        }
        
        .swagger-ui .opblock.opblock-get {
            border-color: #4CAF50 !important;
        }
        
        .swagger-ui .opblock.opblock-get .opblock-summary-method {
            background-color: #4CAF50 !important;
        }
        
        .swagger-ui .opblock.opblock-post {
            border-color: #FF4500 !important;
        }
        
        .swagger-ui .opblock.opblock-post .opblock-summary-method {
            background-color: #FF4500 !important;
        }
        
        .swagger-ui .opblock.opblock-delete {
            border-color: #F44336 !important;
        }
        
        .swagger-ui .opblock.opblock-delete .opblock-summary-method {
            background-color: #F44336 !important;
        }
        
        .swagger-ui .opblock.opblock-put {
            border-color: #FF9800 !important;
        }
        
        .swagger-ui .opblock.opblock-put .opblock-summary-method {
            background-color: #FF9800 !important;
        }
        
        .swagger-ui .opblock.opblock-patch {
            border-color: #9C27B0 !important;
        }
        
        .swagger-ui .opblock.opblock-patch .opblock-summary-method {
            background-color: #9C27B0 !important;
        }
        
        .swagger-ui .opblock-description-wrapper p, 
        .swagger-ui .opblock-external-docs-wrapper p, 
        .swagger-ui .opblock-title_normal p {
            font-size: 16px !important;
            line-height: 1.6 !important;
            margin: 0 0 15px 0 !important;
        }
        
        .swagger-ui table {
            width: 100% !important;
            border-collapse: collapse !important;
            margin: 15px 0 !important;
        }
        
        .swagger-ui table thead tr th {
            background-color: #f8f9fa !important;
            color: #212121 !important;
            padding: 12px 15px !important;
            text-align: left !important;
            border-bottom: 2px solid #e9ecef !important;
        }
        
        .swagger-ui table tbody tr td {
            padding: 12px 15px !important;
            border-bottom: 1px solid #e9ecef !important;
        }
        
        .swagger-ui .btn {
            border-radius: 4px !important;
            padding: 8px 15px !important;
            font-weight: 500 !important;
            transition: all 0.3s ease !important;
        }
        
        .swagger-ui .btn.execute {
            background-color: #FF4500 !important;
            color: white !important;
            border-color: #FF4500 !important;
        }
        
        .swagger-ui .btn.execute:hover {
            background-color: #E03E00 !important;
        }
        
        .swagger-ui .btn.try-out__btn {
            background-color: #4CAF50 !important;
            color: white !important;
            border-color: #4CAF50 !important;
        }
        
        .swagger-ui .btn.try-out__btn:hover {
            background-color: #3D9140 !important;
        }
        
        .swagger-ui .btn.cancel {
            background-color: #F44336 !important;
            color: white !important;
            border-color: #F44336 !important;
        }
        
        .swagger-ui .btn.cancel:hover {
            background-color: #D32F2F !important;
        }
        
        .swagger-ui .btn.authorize {
            background-color: #4CAF50 !important;
            color: white !important;
            border-color: #4CAF50 !important;
        }
        
        .swagger-ui .btn.authorize:hover {
            background-color: #3D9140 !important;
        }
        
        .swagger-ui .parameter__name {
            font-weight: 600 !important;
            color: #212121 !important;
        }
        
        .swagger-ui .parameter__in {
            color: #757575 !important;
            font-style: italic !important;
        }
        
        .swagger-ui input[type=text], 
        .swagger-ui textarea {
            border: 1px solid #e0e0e0 !important;
            border-radius: 4px !important;
            padding: 8px 12px !important;
            width: 100% !important;
            margin: 5px 0 !important;
        }
        
        .swagger-ui input[type=text]:focus, 
        .swagger-ui textarea:focus {
            border-color: #4CAF50 !important;
            outline: none !important;
            box-shadow: 0 0 0 2px rgba(76, 175, 80, 0.25) !important;
        }
        
        .swagger-ui .markdown p, 
        .swagger-ui .markdown li {
            font-size: 16px !important;
            line-height: 1.6 !important;
            margin: 0 0 10px 0 !important;
        }
        
        .swagger-ui .markdown h1, 
        .swagger-ui .markdown h2, 
        .swagger-ui .markdown h3 {
            color: #212121 !important;
            margin: 30px 0 15px 0 !important;
        }
        
        .swagger-ui .markdown h1 {
            font-size: 28px !important;
            border-bottom: 2px solid #e9ecef !important;
            padding-bottom: 10px !important;
        }
        
        .swagger-ui .markdown h2 {
            font-size: 24px !important;
        }
        
        .swagger-ui .markdown h3 {
            font-size: 20px !important;
        }
        
        .swagger-ui .markdown code {
            background-color: #f8f9fa !important;
            padding: 3px 6px !important;
            border-radius: 3px !important;
            color: #FF4500 !important;
            font-family: 'SFMono-Regular', Consolas, 'Liberation Mono', Menlo, monospace !important;
        }
        
        .swagger-ui .markdown pre {
            background-color: #f8f9fa !important;
            padding: 15px !important;
            border-radius: 4px !important;
            overflow-x: auto !important;
            margin: 15px 0 !important;
        }
        
        .swagger-ui .markdown pre code {
            background-color: transparent !important;
            padding: 0 !important;
            color: #212121 !important;
        }
        
        .swagger-ui .markdown table {
            width: 100% !important;
            border-collapse: collapse !important;
            margin: 15px 0 !important;
        }
        
        .swagger-ui .markdown table th {
            background-color: #f8f9fa !important;
            color: #212121 !important;
            padding: 12px 15px !important;
            text-align: left !important;
            border: 1px solid #e9ecef !important;
        }
        
        .swagger-ui .markdown table td {
            padding: 12px 15px !important;
            border: 1px solid #e9ecef !important;
        }
        
        /* Responsividade */
        @media (max-width: 768px) {
            .swagger-ui .info .title {
                font-size: 28px !important;
            }
            
            .swagger-ui .opblock-tag {
                font-size: 18px !important;
            }
            
            .swagger-ui .opblock .opblock-summary-method {
                min-width: 60px !important;
                padding: 6px 8px !important;
            }
            
            .swagger-ui table thead tr th,
            .swagger-ui table tbody tr td {
                padding: 8px 10px !important;
            }
        }
        
        @media (max-width: 576px) {
            .swagger-ui .info .title {
                font-size: 24px !important;
            }
            
            .swagger-ui .opblock-tag {
                font-size: 16px !important;
            }
            
            .swagger-ui .markdown h1 {
                font-size: 24px !important;
            }
            
            .swagger-ui .markdown h2 {
                font-size: 20px !important;
            }
            
            .swagger-ui .markdown h3 {
                font-size: 18px !important;
            }
        }
    </style>
</head>
<body>
    <div id="swagger-ui"></div>
    <script src="https://cdn.jsdelivr.net/npm/swagger-ui-dist@5.9.0/swagger-ui-bundle.js"></script>
    <script>
        window.onload = function() {
            const ui = SwaggerUIBundle({
                url: "/openapi.json",
                dom_id: '#swagger-ui',
                deepLinking: true,
                presets: [
                    SwaggerUIBundle.presets.apis,
                    SwaggerUIBundle.SwaggerUIStandalonePreset
                ],
                layout: "BaseLayout",
                docExpansion: "list",
                defaultModelsExpandDepth: 1,
                defaultModelExpandDepth: 1,
                displayRequestDuration: true,
                filter: true,
                syntaxHighlight: {
                    activate: true,
                    theme: "agate"
                },
                tagsSorter: "alpha",
                operationsSorter: "alpha",
                supportedSubmitMethods: ["get", "post", "put", "delete", "patch"],
                validatorUrl: null,
                persistAuthorization: true,
                tryItOutEnabled: true
            });
            window.ui = ui;
        };
    </script>
</body>
</html>
"""

# Rota para documentação Swagger personalizada
@app.get("/docs", include_in_schema=False)
async def custom_swagger_ui_html():
    return HTMLResponse(content=SWAGGER_UI_HTML)

# Personalização do esquema OpenAPI
def custom_openapi():
    if app.openapi_schema:
        return app.openapi_schema
    
    openapi_schema = get_openapi(
        title=app.title,
        version=app.version,
        description=app.description,
        routes=app.routes,
    )
    
    # Personalização de tags
    openapi_schema["tags"] = [
        {
            "name": "llm",
            "description": "Endpoints para integração com modelos de linguagem (LLMs)",
            "externalDocs": {
                "description": "Documentação detalhada",
                "url": "https://synapscale.ai/docs/llm-integration"
            }
        },
        {
            "name": "files",
            "description": "Endpoints para gerenciamento de arquivos",
            "externalDocs": {
                "description": "Documentação detalhada",
                "url": "https://synapscale.ai/docs/file-management"
            }
        },
        {
            "name": "health",
            "description": "Endpoints para verificação de saúde da aplicação"
        },
        {
            "name": "root",
            "description": "Endpoints raiz da aplicação"
        }
    ]
    
    # Personalização de componentes de segurança
    openapi_schema["components"]["securitySchemes"] = {
        "bearerAuth": {
            "type": "http",
            "scheme": "bearer",
            "bearerFormat": "JWT",
            "description": "Token JWT de autenticação"
        }
    }
    
    # Personalização de exemplos para endpoints LLM
    for path in openapi_schema["paths"]:
        if "/api/v1/llm/chat" in path:
            for method in openapi_schema["paths"][path]:
                if method.lower() == "post":
                    # Adicionar exemplos de requisição
                    if "requestBody" in openapi_schema["paths"][path][method]:
                        content = openapi_schema["paths"][path][method]["requestBody"]["content"]
                        if "application/json" in content:
                            content["application/json"]["examples"] = {
                                "OpenAI GPT-4": {
                                    "summary": "Exemplo com OpenAI GPT-4",
                                    "value": {
                                        "provider": "openai",
                                        "model": "gpt-4o",
                                        "prompt": "Explique o conceito de inteligência artificial em termos simples.",
                                        "temperature": 0.7,
                                        "max_tokens": 500
                                    }
                                },
                                "Claude 3 Opus": {
                                    "summary": "Exemplo com Claude 3 Opus",
                                    "value": {
                                        "provider": "claude",
                                        "model": "claude-3-opus-20240229",
                                        "prompt": "Explique o conceito de inteligência artificial em termos simples.",
                                        "temperature": 0.5,
                                        "max_tokens": 800
                                    }
                                },
                                "Gemini Pro": {
                                    "summary": "Exemplo com Gemini Pro",
                                    "value": {
                                        "provider": "gemini",
                                        "model": "gemini-1.5-pro",
                                        "prompt": "Explique o conceito de inteligência artificial em termos simples.",
                                        "temperature": 0.8,
                                        "max_tokens": 600
                                    }
                                }
                            }
    
    app.openapi_schema = openapi_schema
    return app.openapi_schema

app.openapi = custom_openapi

# Rota para verificação de saúde
@app.get("/health", tags=["health"])
async def health_check():
    """
    Verifica o status de saúde da API.
    
    Retorna status 200 OK se a API estiver funcionando corretamente.
    """
    return {"status": "healthy", "version": app.version, "environment": settings.ENVIRONMENT}

# Rota raiz
@app.get("/", tags=["root"])
async def root():
    """
    Rota raiz da API SynapScale.
    
    Retorna informações básicas sobre a API e links para documentação.
    """
    return {
        "name": "SynapScale Backend API",
        "version": app.version,
        "description": "API para integração com múltiplos provedores de LLM e gerenciamento de arquivos",
        "documentation": "/docs",
        "health": "/health"
    }

# Manipulador de exceções global
@app.exception_handler(Exception)
async def global_exception_handler(request: Request, exc: Exception):
    logger.error(f"Erro não tratado: {exc}", exc_info=True)
    return JSONResponse(
        status_code=500,
        content={"detail": "Erro interno do servidor. Por favor, contate o suporte."}
    )

# Middleware para logging de requisições
@app.middleware("http")
async def log_requests(request: Request, call_next):
    logger.info(f"{request.method} {request.url.path}")
    response = await call_next(request)
    logger.info(f"{request.method} {request.url.path} - {response.status_code}")
    return response

# Inicialização de serviços
@app.on_event("startup")
async def startup_event():
    logger.info(f"Aplicação SynapScale Backend API v{app.version} configurada no ambiente {settings.ENVIRONMENT}")
    logger.info("🚀 Iniciando serviço de uploads...")
    
    # Garantir que diretórios de upload existam
    os.makedirs(settings.UPLOAD_DIR, exist_ok=True)
    
    # Inicializar banco de dados
    try:
        from synapse.db.base import init_db
        await init_db()
    except Exception as e:
        logger.warning(f"Erro ao inicializar banco de dados: {e}")
    
    logger.info("✅ Serviço de uploads inicializado com sucesso")

# Encerramento de serviços
@app.on_event("shutdown")
async def shutdown_event():
    logger.info("👋 Encerrando serviço de uploads...")
