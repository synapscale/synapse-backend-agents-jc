"""Inicialização do pacote de serviços.

Este módulo exporta os serviços de negócio do sistema.
"""

from .file_service import FileService

__all__ = ["FileService"]
