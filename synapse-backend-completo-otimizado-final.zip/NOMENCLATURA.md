# Guia de Padronização de Nomenclatura

Consulte o arquivo principal em `./synapse-backend/docs/NOMENCLATURA.md` para as convenções completas de nomenclatura utilizadas no SynapScale.
